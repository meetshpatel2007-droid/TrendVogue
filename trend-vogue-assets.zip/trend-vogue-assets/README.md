# Trend Vogue — Seed Asset Pack

This pack is for seeding the "Trend Vogue" clothing store with realistic-looking
placeholder data so the site isn't empty on first run.

## What's inside

- `images/` — 24 on-brand placeholder product images (900x1125, portrait),
  6 per category: Men, Women, Kids, Beauty. Each image is labeled with its
  category, product name, and colorway so it's obvious it's a placeholder
  and easy to swap for real photography later.
- `products-metadata.json` — structured data for all 24 products: id, name,
  category, color, price, mrp, discountPercent, sizes, stockQty,
  description, and the matching image path. Field names line up with the
  Prisma `Product` model from the main build prompt, so Antigravity can
  read this file directly in the database seed script.

## How to use with Antigravity

Tell Antigravity:
> "Use `products-metadata.json` and the `images/` folder to write a Prisma
> seed script (`prisma/seed.ts`) that creates the 4 categories and inserts
> all 24 products with their image paths, sizes, prices, and stock."

Copy the images into `frontend/public/products/` (or upload them to your
storage bucket if using Supabase Storage / S3) and update the `image` path
in the metadata accordingly if needed.

## Note on the images

These are generated placeholders (colored blocks + text), not real product
photography — real photos are copyrighted, so they can't be scraped/bundled
here. Swapping in real photos later is a drop-in replacement: same
filenames, same folder, same metadata structure — no code changes required.
